import { TestBed } from '@angular/core/testing';

import { BackEndServiceClientService } from './back-end-service-client.service';

describe('BackEndServiceClientService', () => {
  let service: BackEndServiceClientService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BackEndServiceClientService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
