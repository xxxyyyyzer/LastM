import { TestBed } from '@angular/core/testing';

import { BackEndServiceCommandesService } from './back-end-service-commandes.service';

describe('BackEndServiceCommandesService', () => {
  let service: BackEndServiceCommandesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BackEndServiceCommandesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
