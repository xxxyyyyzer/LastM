package com.lastMarket.spring.jpa.h2.repository;

import com.lastMarket.spring.jpa.h2.model.Commande;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CommandesRepository extends JpaRepository<Commande, Long> {

  List<Commande> findByEtatContaining(String etat);
}
