package com.lastMarket.spring.jpa.h2.objects;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import javax.mail.Address;
import javax.mail.internet.MimeBodyPart;
import java.util.ArrayList;
import java.util.List;

@AllArgsConstructor
@Slf4j
public class Mail {

    public Mail(){
        this.parts = new ArrayList<>();
    }

    @Getter @Setter
    private Address [] from;

    @Getter @Setter
    private Address[] to;

    @Getter @Setter
    private String subject;

    @Getter @Setter
    private String content;

    @Getter @Setter
    private int number;

    @Getter @Setter
    private String contentType;

    @Getter @Setter
    private List<MimeBodyPart> parts;

    public void logInfo(boolean showContent){
        log.info("Mail #"  + this.number);
        log.info("Subject : " + this.subject);
        log.info("From : " + convertToString(this.from));
        log.info("To : " + convertToString(this.to));
        if(showContent){
            log.info("content : " +this.content);
        }
    }

    private String convertToString(Address[] adresse){
        StringBuilder res=new StringBuilder();
        if(adresse==null || adresse.length==0){
            return "";
        }
        for (Address adrr:adresse) {
            res.append(adrr.toString()).append(";");
        }
        return res.toString();
    }
}
