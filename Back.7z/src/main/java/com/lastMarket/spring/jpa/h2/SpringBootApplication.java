package com.lastMarket.spring.jpa.h2;

import com.lastMarket.spring.jpa.h2.model.Client;
import com.lastMarket.spring.jpa.h2.model.Commande;
import com.lastMarket.spring.jpa.h2.model.Produit;
import com.lastMarket.spring.jpa.h2.repository.CommandesRepository;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.context.annotation.Bean;

import java.sql.Date;

@org.springframework.boot.autoconfigure.SpringBootApplication
public class SpringBootApplication {
	//@Autowired
	//private CommandesRepository commandesRepository;

	public static void main(String[] args) {
		SpringApplication.run(SpringBootApplication.class, args);
	}
/*
	@Bean
	InitializingBean sendDatabase() {


		Client client = new Client();
		client.setNom("Mombus");
		client.setAdresse("adresse 1");
		client.setPrenom("prenomLaCombatante");
		client.setVille("Le Pecq");
		client.setCodePostal(78230);
		client.setNumeroPortable("0606060606");

		Produit apple1 = new Produit();
		apple1.setMarque("Apple");
		apple1.setModele("iPhone 14 Plus (128 Go)");
		apple1.setClient(client);
		apple1.setCodeVerouillage("de quoi je me mèle");
		//apple1.setDescripionPanne("écran cassé");
		client.getProduits().add(apple1);

		Commande cmd1 = new Commande();
		cmd1.setEtat("Colis reçu");
		cmd1.setDescripionPanne("écran cassé");
		cmd1.setMontant(50f);
		cmd1.setType("Réparation");
		long nowLong = new java.util.Date().getTime();
		cmd1.setDateCreation(new Date(nowLong));

		apple1.getCommandes().add(cmd1);

		//	commandesRepository.save(client);


	}*/
}

