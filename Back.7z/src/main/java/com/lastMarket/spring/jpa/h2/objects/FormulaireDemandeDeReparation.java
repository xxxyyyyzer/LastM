package com.lastMarket.spring.jpa.h2.objects;

import lombok.Getter;
import lombok.Setter;

public class FormulaireDemandeDeReparation {

    @Getter @Setter
    private String nom;

    @Getter @Setter
    private String prenom;

    @Getter @Setter
    private String adresse;

    @Getter @Setter
    private String ville;

    @Getter @Setter
    private int codePostal;

    @Getter @Setter
    private String numeroPortable;

    @Getter @Setter
    private String marque;

    @Getter @Setter
    private String modele;

    @Getter @Setter
    private String codeVerouillage;

    @Getter @Setter
    private String descripionPanne;

}
