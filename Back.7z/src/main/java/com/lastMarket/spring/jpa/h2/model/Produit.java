package com.lastMarket.spring.jpa.h2.model;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "Produit")
@AllArgsConstructor
public class Produit {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column(name = "id_client")
    @Getter @Setter
    private long idClient;

    @Column(name = "marque")
    @Getter @Setter
    private String marque;

    @Column(name = "modele")
    @Getter @Setter
    private String modele;

    @Column(name = "code_verouillage")
    @Getter @Setter
    private String codeVerouillage;

    @Column(name = "date_commande_produit")
    @Getter @Setter
    private Date dateCommandeProduit;

    @Column(name = "type_produit")
    @Getter @Setter
    private String typeProduit;//réparations, achat, leasing

    @OneToMany
    @Getter @Setter
    private List<Commande> commandes  = new ArrayList<>();

    @OneToOne
    @Getter @Setter
    private Client client;

    public Produit(){}

}
