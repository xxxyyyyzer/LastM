export class Client {
  id?: any;
  nom?: string;
  prenom?: string;
  adresse?: string;
  ville?: string;
  numeroPortable?: string;


}
