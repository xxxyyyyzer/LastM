import { TestBed } from '@angular/core/testing';

import { BackEndServiceProduitsService } from './back-end-service-produits.service';

describe('BackEndServiceProduitsService', () => {
  let service: BackEndServiceProduitsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BackEndServiceProduitsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
