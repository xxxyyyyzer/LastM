package com.lastMarket.spring.jpa.h2.repository;


import com.lastMarket.spring.jpa.h2.model.Produit;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ProduitRepository extends JpaRepository<Produit, Long> {


}
