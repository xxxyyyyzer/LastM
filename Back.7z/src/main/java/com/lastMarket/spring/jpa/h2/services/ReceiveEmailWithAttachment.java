package com.lastMarket.spring.jpa.h2.services;

import com.lastMarket.spring.jpa.h2.objects.Mail;
import lombok.extern.slf4j.Slf4j;
import org.apache.tomcat.util.codec.binary.Base64;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeUtility;
import javax.mail.search.FlagTerm;

/**
 * This class is used to receive email with attachment.
 */
@Slf4j
public class ReceiveEmailWithAttachment {

    public static void receiveEmailImap(String imapHost, String userName, String password, int port) throws MessagingException {

        log.info("call receiveEmailImap -> imapHost:" + imapHost + " userName:" + userName + " port:" + port);

        Session session = Session.getDefaultInstance(new Properties( ));
        Store store = session.getStore("imaps");
        store.connect(imapHost, port, userName, password);
        log.info("call receiveEmailImap -> connected !");
        Folder inbox = store.getFolder( "INBOX" );
        inbox.open( Folder.READ_ONLY );

        // Fetch unseen messages from inbox folder
        Message[] messages = inbox.search(new FlagTerm(new Flags(Flags.Flag.SEEN), false));

        // Sort messages from recent to oldest
        Arrays.sort( messages, (m1, m2 ) -> {
            try {
                return m2.getSentDate().compareTo( m1.getSentDate() );
            } catch ( MessagingException e ) {
                throw new RuntimeException( e );
            }
        } );

        for ( Message message : messages ) {
            log.info("sendDate: " + message.getSentDate()  + " subject:" + message.getSubject() );
        }

    }
    public static List<Mail> receiveEmailPop3( String pop3Host, String userName, String password, int port){
        String mailStoreType="pop3";
        log.info("call receiveEmailPop3 -> pop3Host:"+pop3Host+" mailStoreType:"+mailStoreType+" userName:"+userName+ " port:"+port);
        //Set properties
        Properties properties = new Properties();
        List<Mail> mails = new ArrayList<>();

        properties.setProperty("mail.store.protocol", "pop3s");
        properties.setProperty("mail.pop3s.host", pop3Host);
        properties.setProperty("mail.pop3s.port", String.valueOf(port));
        properties.setProperty("mail.pop3s.auth", "true");
        properties.setProperty("mail.pop3s.socketFactory.class",      "javax.net.ssl.SSLSocketFactory" );
        properties.setProperty("mail.pop3s.ssl.trust", "*");
        properties.setProperty("mail.pop3s.ssl.protocols", "TLSv1.2");
        properties.setProperty("mail.pop3s.starttls.enable", "true");
        // Get the Session object.
        Session session = Session.getInstance(properties);

        try {
            //Create the POP3 store object and connect to the pop store.
            Store store = session.getStore("pop3s");
            store.connect(pop3Host, userName, password);
            log.info("call receiveEmailPop3 -> connected !");

            //Create the folder object and open it in your mailbox.
            Folder emailFolder = store.getFolder("INBOX");
            emailFolder.open(Folder.READ_ONLY);

            //Retrieve the messages from the folder object.
            Message[] messages = emailFolder.getMessages();
            log.info("Total Message : " + messages.length);


            //Iterate the messages
            final Long start = System.currentTimeMillis();
            int i=0;
            Mail mail;
            for (Message message:messages) {
                i++;
                log.info("read mail #"+i+"/"+messages.length);
                mail = new Mail() ;
                Address[] toAddress = message.getRecipients(Message.RecipientType.TO);
                mail.setSubject(message.getSubject());
                mail.setTo(toAddress);
                mail.setFrom(message.getFrom());
                mail.setNumber(i);

                log.info("Subject:"+mail.getSubject());

                //Iterate multiparts
                try {
                    if (message.getContent() == null) {
                        log.info("continue #" + i);
                        continue;
                    }
                }catch (Exception e){
                    log.error("Error on mail #"+i,e);
                }
                StringBuilder str = new StringBuilder();
                String contentType = message.getContentType();
                mail.setContentType(contentType);
                log.debug("contentType:"+contentType);
                try {
                    if (contentType.contains("multipart")) {
                        // content may contain attachments
                        Multipart multiPart = (Multipart) message.getContent();
                        int numberOfParts = multiPart.getCount();
                        log.debug("multipart numberOfParts:"+numberOfParts);
                        int j=0;
                        for (int partCount = 0; partCount < numberOfParts; partCount++) {
                            j++;
                            MimeBodyPart part = (MimeBodyPart) multiPart.getBodyPart(partCount);
                            try {
                                if (Part.ATTACHMENT.equalsIgnoreCase(part.getDisposition())) {
                                    // this part is attachment
                                    String fileName = part.getFileName();
                                    log.debug("Find attachment '"+fileName+"'");
                                   // attachFiles += fileName + ", ";
                                   // part.saveFile(saveDirectory + File.separator + fileName);
                                    mail.getParts().add(part);
                                } else {
                                    // this part may be the message content
                                    //messageContent = part.getContent().toString();
                                    try{
                                        mail.setContent(part.getContent().toString());
                                    }catch(java.io.UnsupportedEncodingException e ){
                                        log.error("Error parsing content 1 (part #"+j+" ): ",e);
                                        //TODO traiter les erreurs java.io.UnsupportedEncodingException: UTF-8-Base64
                                    }
                                }
                            }catch (Exception e){
                                log.error("Error on mail #"+i,e);
                            }
                        }
    /*
                        if (attachFiles.length() > 1) {
                            attachFiles = attachFiles.substring(0, attachFiles.length() - 2);
                        }*/
                    } else if (contentType.contains("text/plain")
                            || contentType.contains("text/html")) { // if (contentType.contains("multipart")) {
                        Object content = null;
                        try {
                            content = message.getContent();
                        }catch(java.io.UnsupportedEncodingException e ){
                            log.error("Error parsing content 2 : ",e);
                            //TODO traiter les erreurs java.io.UnsupportedEncodingException: UTF-8-Base64
                           // MimeUtility.encodeText(message.getContent());
                           // byte[] decodedBytes = Base64.decodeBase64(message.getContent());
                        }

                        if (content != null) {
                           // messageContent = content.toString();
                            mail.setContent(content.toString());
                        }
                    }//else if (contentType.contains("text/plain")
                }catch (Exception e){
                    log.error("Error on mail #"+i,e);
                }
/*

                try {
                    if(message.getContent() instanceof Multipart){
                        Multipart multipart = (Multipart) message.getContent();
                        String multipartContentType =  multipart.getContentType();
                        //log.info("multipartContentType:"+multipartContentType);
                        for(int k = 0; k < multipart.getCount(); k++){
                            BodyPart bodyPart = multipart.getBodyPart(k);
                            InputStream stream =  (InputStream) bodyPart.getInputStream();
                            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(stream));
                            while (bufferedReader.ready()) {
                                str.append(bufferedReader.readLine());
                               // log.info(str.toString());
                            }
                        }
                    }else{
                        if(message.getContent() instanceof String){
                            str=new StringBuilder((String)message.getContent());
                        }
                    }
                }catch (Exception e){
                    log.error("Error on mail #"+i,e);
                }
                mail.setContent(str.toString());*/
                mails.add(mail);
            }

            final Long end = System.currentTimeMillis();
            log.info("Spend time to read mail : "+(end-start) +" ms -> "+ (end-start)/1000+" sec. -> "+(end-start)/60000+" min. ");

            //close the folder and store objects
            emailFolder.close(false);
            store.close();
        } catch (NoSuchProviderException e) {
           log.error("error : ",e);
        } catch (MessagingException e){
            log.error("error : ",e);
        } catch (Exception e) {
            log.error("error : ",e);
        }
        return mails;
    }

    //TODO a mettre dans service specifique
    public static void traiterMailsDemandeDeReparation(List<Mail> mails){
        log.info("traiterMailsDemandeDeReparation -> "+mails.size()+" mails");
        int i=0;
        for (Mail mail:mails) {
            log.info("Subject:"+mail.getSubject());
            if(mail.getSubject()!=null && mail.getSubject().indexOf("Demande_de_reparation")!=-1){
                i++;
                log.info("Demande de reparation #"+i+" trouvée subject:"+mail.getSubject());
            }
        }
        log.info("traiterMailsDemandeDeReparation -> fin");
    }



    public static void main(String[] args) {



        String pop3Host = "pop.ionos.fr";//change accordingly
        String mailStoreType = "pop3";
        String userName = "w3spoint";//change accordingly
        String password = "****";//change accordingly

        String adresse = "Contact@last-market.com";
        String mdp = "Au2Ro2020*";

        userName=adresse;
        password =mdp;


        /*
        https://www.ionos.fr/assistance/email/sujets-generaux/parametres-pour-les-programmes-de-messagerie/

        Données de connexion pour le serveur de messagerie IONOS

Paramétrage du serveur de courrier entrant (IMAP, POP3)


TYPE DE COMPTE	                    IMAP	        POP3
Serveur     	                    imap.ionos.fr	pop.ionos.fr
Port	                            993	            995
Type de connexion / Chiffrement	    SSL/TLS	        SSL/TLS


Paramétrage du serveur de courrier sortant (SMTP)

Serveur	smtp.ionos.fr
Port	465
Type de connexion	SSL/TLS

        */

        //call receiveEmail POP3
        List<Mail> mails = receiveEmailPop3(pop3Host, userName, password,995);

        /*
        for (Mail mail:mails) {
            log.info("----------------------------------");
            mail.logInfo(false);
        }
        */

        traiterMailsDemandeDeReparation(mails);



        //call receiveEmail IMAP
        String imapHost = "imap.ionos.fr";
        //(String imapHost, String userName, String password, int port)
        /*
        try {
            receiveEmailImap(imapHost, userName, password,993);
        } catch (MessagingException e) {
            throw new RuntimeException(e);
        }*/
    }


}