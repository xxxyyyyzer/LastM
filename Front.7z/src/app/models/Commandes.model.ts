import { Produits } from 'src/app/models/Produits.model';
import { Client } from 'src/app/models/Client.model';

export class Commandes {
  id?: any;
  etat?: string;
  type?: string;
  montant?: number;
  dateCreation?: Date;
  dateReceptionProduit?: Date;
  dateEnvoieProduit?: Date;
  dateDebutReparation?: Date;
  dateFinReparation?: Date;
  descripionPanne?: string;
  produit?:Produits[];
  client?:Client[];
/*

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @ManyToOne
    @Getter @Setter
    private Produit produit;

    @Column(name = "etat")
    @Getter
    @Setter
    private String etat;

    @Column(name = "type")
    @Getter
    @Setter
    private String type;

    @Column(name = "montant")
    @Getter
    @Setter
    private float montant;

    @Column(name = "date_creation")
    @Getter
    @Setter
    private Date dateCreation;

    @Column(name = "date_reception_produit")
    @Getter
    @Setter
    private Date dateReceptionProduit;

    @Column(name = "date_envoie_produit")
    @Getter
    @Setter
    private Date dateEnvoieProduit;

    @Column(name = "date_debut_reparation")
    @Getter
    @Setter
    private Date dateDebutReparation;

    @Column(name = "date_fin_reparation")
    @Getter
    @Setter
    private Date dateFinReparation;


    @Column(name = "descripion_panne")
    @Getter @Setter
    private String descripionPanne;
*/

}
