import { Component, OnInit  } from '@angular/core';
import { Produits } from 'src/app/models/Produits.model';
import { BackEndServiceClientService } from 'src/app/services/back-end-service-client.service';
import {Subject} from 'rxjs';

@Component({
  selector: 'app-liste-produits',
  templateUrl: './liste-produits.component.html',
  styleUrls: ['./liste-produits.component.css']
})
export class ListeProduitsComponent implements OnInit  {

data: any;
dtOptions: any = {};


  constructor(private clientsService: BackEndServiceClientService) { }

  ngOnInit(): void {


      this.dtOptions = {
         pagingType: 'full_numbers',
         pageLength: 3,
         processing: true,
         dom: 'Bfrtip',
           buttons: [
               'copy', 'csv', 'excel', 'print'
           ]
       };

   this.clientsService.getAllProduits().subscribe(
        items => {
         this.data = items;
        });

  }
}
