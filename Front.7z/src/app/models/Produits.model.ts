export class Produits {
  id?: any;
  id_client?: any;
  marque?: string;
  modele?: string;
  codeVerouillage?: string;
  date_commande_produit?: Date;
  type_produit?: string;

/*
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column(name = "id_client")
    @Getter @Setter
    private long idClient;

    @Column(name = "marque")
    @Getter @Setter
    private String marque;

    @Column(name = "modele")
    @Getter @Setter
    private String modele;

    @Column(name = "code_verouillage")
    @Getter @Setter
    private String codeVerouillage;


    @Column(name = "type_produit")
    @Getter @Setter
    private String typeProduit;//réparations, achat, leasing

    @OneToMany
    @Getter @Setter
    private List<Commande> commandes  = new ArrayList<>();
*/


}
