package com.lastMarket.spring.jpa.h2.tools;


public class CommonTools {

}
