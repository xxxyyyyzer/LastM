import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Client } from '../models/Client.model';
const baseUrl = 'http://localhost:8080/api/client/liste';

@Injectable({
  providedIn: 'root'
})
export class BackEndServiceClientService {

  constructor(private http: HttpClient) { }

  getAll(): Observable<Client[]> {
    return this.http.get<Client[]>(baseUrl);
  }
}
