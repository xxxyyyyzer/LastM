package com.lastMarket.spring.jpa.h2.model;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.sql.Date;


@Entity
@Table(name = "Commande")
public class Commande {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @ManyToOne
    @Getter @Setter
    private Produit produit;

    @ManyToOne
    @Getter @Setter
    private Client client;

    @Column(name = "etat")
    @Getter
    @Setter
    private String etat;

    @Column(name = "type")
    @Getter
    @Setter
    private String type;

    @Column(name = "montant")
    @Getter
    @Setter
    private float montant;

    @Column(name = "date_creation")
    @Getter
    @Setter
    private Date dateCreation;

    @Column(name = "date_reception_produit")
    @Getter
    @Setter
    private Date dateReceptionProduit;

    @Column(name = "date_envoie_produit")
    @Getter
    @Setter
    private Date dateEnvoieProduit;

    @Column(name = "date_debut_reparation")
    @Getter
    @Setter
    private Date dateDebutReparation;

    @Column(name = "date_fin_reparation")
    @Getter
    @Setter
    private Date dateFinReparation;


    @Column(name = "descripion_panne")
    @Getter @Setter
    private String descripionPanne;



}
