import { Injectable } from '@angular/core';
import { HttpClient , HttpErrorResponse} from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import {catchError, map} from 'rxjs/operators';

import { Client } from '../models/Client.model';
const baseUrl = 'http://localhost:8080/api/';

@Injectable({
  providedIn: 'root'
})
export class BackEndServiceClientService {


 constructor(private http: HttpClient) { }

  getAllClients(): Observable<Client[]> {
    console.log('BackEndServiceClientService getAll URL:'+baseUrl+'client/liste');
    return this.http.get<Client[]>(baseUrl+'client/liste')
                     .pipe(
      catchError((error) => {
        console.log('error is intercept')
        console.error(error);
        return throwError(error.message);
      }));
  }

  getAllCommandes(): Observable<Client[]> {
    console.log('BackEndServiceClientService getAll URL:'+baseUrl+'commande/liste');
    return this.http.get<Client[]>(baseUrl+'commande/liste')
                     .pipe(
      catchError((error) => {
        console.log('error is intercept')
        console.error(error);
        return throwError(error.message);
      }));
  }

  getAllProduits(): Observable<Client[]> {
    console.log('BackEndServiceClientService getAll URL:'+baseUrl+'produit/liste');
    return this.http.get<Client[]>(baseUrl+'produit/liste')
                     .pipe(
      catchError((error) => {
        console.log('error is intercept')
        console.error(error);
        return throwError(error.message);
      }));
  }
}
