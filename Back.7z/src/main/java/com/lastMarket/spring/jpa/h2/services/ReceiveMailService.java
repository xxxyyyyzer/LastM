package com.lastMarket.spring.jpa.h2.services;

import javax.mail.internet.MimeMessage;

public interface ReceiveMailService {

    void handleReceivedMail(MimeMessage message);

}
