package com.lastMarket.spring.jpa.h2.model;

import jakarta.persistence.*;
import lombok.*;

import java.sql.Date;
import java.util.List;
import java.util.ArrayList;

@Entity
@Table(name = "Client")
@AllArgsConstructor
public class Client {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column(name = "nom")
    @Getter @Setter
    private String nom;

    @Column(name = "prenom")
    @Getter @Setter
    private String prenom;

    @Column(name = "adresse")
    @Getter @Setter
    private String adresse;

    @Column(name = "ville")
    @Getter @Setter
    private String ville;

    @Column(name = "code_postal")
    @Getter @Setter
    private int codePostal;

    @Column(name = "numero_portable")
    @Getter @Setter
    private String numeroPortable;

    @OneToMany
    @Getter @Setter
    private List<Produit> produits = new ArrayList<>();

    @OneToMany
    @Getter @Setter
    private List<Commande> commandes = new ArrayList<>();

    @Column(name = "datePremiereCommande")
    @Getter @Setter
    private Date datePremiereCommande;

    public Client(){

    }
}
