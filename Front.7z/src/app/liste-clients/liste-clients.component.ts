import { Component, OnInit } from '@angular/core';
import { Client } from 'src/app/models/Client.model';
import { BackEndServiceClientService } from 'src/app/services/back-end-service-client.service';
import {Subject} from 'rxjs';

@Component({
  selector: 'app-liste-clients',
  templateUrl: './liste-clients.component.html',
  styleUrls: ['./liste-clients.component.css']
})
export class ListeClientsComponent implements OnInit {

data: any;
dtOptions: any = {};


  constructor(private clientsService: BackEndServiceClientService) { }

  ngOnInit(): void {

      this.dtOptions = {
         pagingType: 'full_numbers',
         pageLength: 3,
         processing: true,
         dom: 'Bfrtip',
           buttons: [
               'copy', 'csv', 'excel', 'print'
           ]
       };

   this.clientsService.getAllClients().subscribe(
        items => {
         this.data = items;
        });

  }


}
