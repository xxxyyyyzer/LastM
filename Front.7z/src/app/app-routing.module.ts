import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ListeClientsComponent } from './liste-clients/liste-clients.component';
import { ListeCommandesComponent } from './liste-commandes/liste-commandes.component';
import { ListeProduitsComponent } from './liste-produits/liste-produits.component';


const routes: Routes = [
  { path: '', redirectTo: 'listeCommandes', pathMatch: 'full' },
  { path: 'listeProduits', component: ListeProduitsComponent },
  { path: 'listeClients', component: ListeClientsComponent },
  { path: 'listeCommandes', component: ListeCommandesComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
