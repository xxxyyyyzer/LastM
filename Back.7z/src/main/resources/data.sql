
/* Insertions pour faire des tests */
INSERT INTO Client (id,nom,prenom,adresse,ville,code_postal,numero_portable) VALUES (1,'nom1','Thibault','adresse1', 'Nanterre',78230,'06.06.06.06.01');
INSERT INTO Client (id,nom,prenom,adresse,ville,code_postal,numero_portable) VALUES (2,'nom2','Christiane','adresse2', 'Paris',78230,'06.06.06.06.02');
INSERT INTO Client (id,nom,prenom,adresse,ville,code_postal,numero_portable) VALUES (3,'nom3','prenom3','adresse3', 'Puteaux',78230,'06.06.06.06.03');

INSERT INTO Produit (id,id_client,marque,modele,code_verouillage,date_commande_produit, type_produit) VALUES (1,1,'Apple','iphone 14 plus','1234','2023-06-01','Réparation');
INSERT INTO Produit (id,id_client,marque,modele,code_verouillage,date_commande_produit, type_produit) VALUES (2,1,'Samsung','galaxy S21','1234','2023-06-02','Réparation');
INSERT INTO Produit (id,id_client,marque,modele,code_verouillage,date_commande_produit, type_produit) VALUES (3,2,'Samsung','galaxy S9','5432','2023-06-03','Réparation');

/*
INSERT INTO client_produits (client_id, produits_id) VALUES (1,1);
INSERT INTO client_produits (client_id, produits_id) VALUES (1,2);
INSERT INTO client_produits (client_id, produits_id) VALUES (2,3);
*/

INSERT INTO commande (id,date_creation,date_debut_reparation, date_envoie_produit, date_fin_reparation, date_reception_produit, descripion_panne, etat, montant, type, produit_id,client_id) VALUES
(1,'2023-05-31',null, null, null, null, 'ecran apple casé', 'commande à envoyer par le client', 50, 'réparation', 1,1);
INSERT INTO commande (id,date_creation,date_debut_reparation, date_envoie_produit, date_fin_reparation, date_reception_produit, descripion_panne, etat, montant, type, produit_id,client_id) VALUES
(2,'2023-05-30',null, null, null, null, 'ecran samsung s21 KO', 'commande à envoyer par le client', 50, 'réparation', 2,1);
INSERT INTO commande (id,date_creation,date_debut_reparation, date_envoie_produit, date_fin_reparation, date_reception_produit, descripion_panne, etat, montant, type, produit_id,client_id) VALUES
(3,'2023-05-30',null, null, null, null, 'ecran samsung s9 KO', 'commande à envoyer par le client', 50, 'réparation', 3,2);

/*
INSERT INTO produit_commandes (produit_id, commandes_id) VALUES (1,1);
INSERT INTO produit_commandes (produit_id, commandes_id) VALUES (2,2);
INSERT INTO produit_commandes (produit_id, commandes_id) VALUES (3,3);
*/

/*

Hibernate: create table client (id bigint not null, adresse varchar(255), code_postal integer, date_premiere_commande date, nom varchar(255), numero_portable varchar(255), prenom varchar(255), ville varchar(255), primary key (id))
Hibernate: create table client_produits (client_id bigint not null, produits_id bigint not null)
Hibernate: create table commande (id bigint not null, date_creation date, date_debut_reparation date, date_envoie_produit date, date_fin_reparation date, date_reception_produit date, descripion_panne varchar(255), etat varchar(255), montant float(24), type varchar(255), produit_id bigint, primary key (id))
Hibernate: create table produit (id bigint not null, code_verouillage varchar(255), id_client bigint, marque varchar(255), modele varchar(255), type_produit varchar(255), primary key (id))
Hibernate: create table produit_commandes (produit_id bigint not null, commandes_id bigint not null)
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column(name = "idClient")
    @Getter @Setter
    private long idClient;

    @Column(name = "marque")
    @Getter @Setter
    private String marque;

    @Column(name = "modele")
    @Getter @Setter
    private String modele;

    @Column(name = "codeVerouillage")
    @Getter @Setter
    private String codeVerouillage;


    @Column(name = "type_produit")
    @Getter @Setter
    private String typeProduit;//réparations, achat, leasing
    */