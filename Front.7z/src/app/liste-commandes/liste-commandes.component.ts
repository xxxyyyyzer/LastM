import { Component, OnInit } from '@angular/core';
import { Commandes } from 'src/app/models/Commandes.model';
import { BackEndServiceClientService } from 'src/app/services/back-end-service-client.service';
import {Subject} from 'rxjs';

@Component({
  selector: 'app-liste-commandes',
  templateUrl: './liste-commandes.component.html',
  styleUrls: ['./liste-commandes.component.css']
})
export class ListeCommandesComponent implements OnInit {


data: any;
dtOptions: any = {};

  constructor(private clientsService: BackEndServiceClientService) { }

  ngOnInit(): void {
      this.dtOptions = {
         pagingType: 'full_numbers',
         pageLength: 3,
         processing: true,
         dom: 'Bfrtip',
           buttons: [
               'copy', 'csv', 'excel', 'print'
           ]
       };

   this.clientsService.getAllCommandes().subscribe(
        items => {
         this.data = items;
        });

  }
}
